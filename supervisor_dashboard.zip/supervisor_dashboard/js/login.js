const API_BASE_URL = 'https://tarieky-production-d0ae.up.railway.app/api';
const AUTH_BASE_URL = 'https://tarieky-production-d0ae.up.railway.app/auth';

function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}

function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for(let i=0;i < ca.length;i++) {
        let c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

document.addEventListener('DOMContentLoaded', () => {
    // Check if already logged in
    if (getCookie('token')) {
        window.location.href = 'index.html';
        return;
    }

    const loginForm = document.getElementById('login-form');
    const loginError = document.getElementById('login-error');
    const loginBtn = document.getElementById('login-btn');
    
    // Modal elements
    const signupBtn = document.getElementById('signup-btn');
    const signupModal = document.getElementById('signup-modal');
    const closeModalBtn = document.querySelector('.close-modal');

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        loginBtn.disabled = true;
        loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحقق...';
        loginError.style.display = 'none';
        
        try {
            const response = await fetch(`${AUTH_BASE_URL}/log-in/api/token/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                // Save tokens in cookies
                setCookie('token', data.access, 1); // 1 day
                setCookie('refresh_token', data.refresh, 7); // 7 days
                
                // Fetch profile to verify supervisor status
                const profileRes = await fetch(`${API_BASE_URL}/profile/`, {
                    headers: { 'Authorization': `Bearer ${data.access}` }
                });
                
                if (profileRes.ok) {
                    const profileData = await profileRes.json();
                    
                    if (profileData.is_supervisor) {
                        setCookie('user_info', JSON.stringify(profileData), 1);
                        window.location.href = 'index.html';
                    } else {
                        loginError.textContent = 'عذراً، هذا الحساب ليس لديه صلاحيات مشرف.';
                        loginError.style.display = 'block';
                        // Remove tokens if not supervisor
                        document.cookie = 'token=; Max-Age=-99999999; path=/;';
                        document.cookie = 'refresh_token=; Max-Age=-99999999; path=/;';
                    }
                }
            } else {
                loginError.textContent = 'بيانات الدخول غير صحيحة.';
                loginError.style.display = 'block';
            }
        } catch (error) {
            console.error('Login error:', error);
            loginError.textContent = 'حدث خطأ في الاتصال بالخادم.';
            loginError.style.display = 'block';
        } finally {
            loginBtn.disabled = false;
            loginBtn.innerHTML = '<span>تسجيل الدخول</span><i class="fas fa-arrow-left"></i>';
        }
    });

    // Modal Logic
    signupBtn.addEventListener('click', () => {
        signupModal.style.display = 'flex';
    });

    closeModalBtn.addEventListener('click', () => {
        signupModal.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === signupModal) {
            signupModal.style.display = 'none';
        }
    });
});
