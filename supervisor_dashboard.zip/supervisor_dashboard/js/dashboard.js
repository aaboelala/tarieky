const API_BASE_URL = 'https://tarieky-production-d0ae.up.railway.app/api';
let allIssues = []; // Flat array of all issues
let currentIssueId = null;

function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

document.addEventListener('DOMContentLoaded', () => {
    // Auth Check
    const token = getCookie('token');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    // Load User Info
    const userInfoStr = getCookie('user_info');
    if (userInfoStr) {
        const userInfo = JSON.parse(userInfoStr);
        document.getElementById('user-name').textContent = `${userInfo.first_name || 'مشرف'} ${userInfo.last_name || ''}`;
    }

    // Logout
    document.getElementById('logout-btn').addEventListener('click', () => {
        document.cookie = 'token=; Max-Age=-99999999; path=/;';
        document.cookie = 'refresh_token=; Max-Age=-99999999; path=/;';
        document.cookie = 'user_info=; Max-Age=-99999999; path=/;';
        window.location.href = 'login.html';
    });

    // Initialize Dashboard
    fetchGroupedIssues();

    // Setup Event Listeners
    document.getElementById('refresh-btn').addEventListener('click', fetchGroupedIssues);
    document.getElementById('status-filter').addEventListener('change', filterIssues);

    // Modal Event Listeners
    const modal = document.getElementById('issue-modal');
    document.querySelector('.close-modal').addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Status Buttons Event Listeners
    document.querySelectorAll('.status-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const newStatus = e.target.closest('.status-btn').dataset.status;
            updateIssueStatus(currentIssueId, newStatus);
        });
    });
});

async function fetchGroupedIssues() {
    const container = document.getElementById('issues-container');
    container.innerHTML = `<div class="loader-container"><div class="loader"></div><p>جاري تحميل البلاغات...</p></div>`;

    try {
        const response = await fetch(`${API_BASE_URL}/issues/`, {
            headers: {
                'Authorization': `Bearer ${getCookie('token')}`
            }
        });

        if (response.status === 401) {
            // Token might be expired
            document.cookie = 'token=; Max-Age=-99999999; path=/;';
            window.location.href = 'login.html';
            return;
        }

        if (!response.ok) throw new Error('فشل في جلب البيانات');

        const data = await response.json();
        allIssues = Array.isArray(data) ? data : (data.results || []);

        // Group data locally using Arabic strings returned by the API
        const groupedData = {
            'قيد الانتظار': [],
            'جاري العمل': [],
            'تم الحل': [],
            'تم الرفض': []
        };

        allIssues.forEach(issue => {
            if (groupedData[issue.status]) {
                groupedData[issue.status].push(issue);
            } else {
                groupedData[issue.status] = [issue];
            }
        });

        // Update Stats
        document.getElementById('count-pending').textContent = groupedData['قيد الانتظار'].length;
        document.getElementById('count-inprogress').textContent = groupedData['جاري العمل'].length;
        document.getElementById('count-resolved').textContent = groupedData['تم الحل'].length;
        document.getElementById('count-rejected').textContent = groupedData['تم الرفض'].length;

        // Sort by created_at (newest first)
        allIssues.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        filterIssues(); // Render based on current filter

    } catch (error) {
        console.error('Error fetching issues:', error);
        container.innerHTML = `<div class="error-message">حدث خطأ أثناء جلب البلاغات. يرجى المحاولة مرة أخرى.</div>`;
        showToast('فشل في الاتصال بالخادم', 'error');
    }
}

function filterIssues() {
    const filterVal = document.getElementById('status-filter').value;
    const container = document.getElementById('issues-container');

    container.innerHTML = '';

    const filteredIssues = filterVal === 'all'
        ? allIssues
        : allIssues.filter(issue => issue.status === filterVal);

    if (filteredIssues.length === 0) {
        container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #666;">لا توجد بلاغات لهذه الحالة.</div>`;
        return;
    }

    filteredIssues.forEach(issue => {
        container.appendChild(createIssueCard(issue));
    });
}

function createIssueCard(issue) {
    const card = document.createElement('div');
    card.className = 'issue-card';

    const statusMap = {
        'قيد الانتظار': { text: 'قيد الانتظار', class: 'status-pending' },
        'جاري العمل': { text: 'جاري العمل', class: 'status-inprogress' },
        'تم الحل': { text: 'تم الحل', class: 'status-resolved' },
        'تم الرفض': { text: 'تم الرفض', class: 'status-rejected' }
    };

    const categoryMap = {
        'lighting': 'إنارة',
        'pothole': 'نقرة',
        'speed_bump': 'مطب',
        'traffic_sign': 'لافتة مرورية',
        'road_damage': 'تلف طريق',
        'other': 'أخرى'
    };

    const statusInfo = statusMap[issue.status] || { text: issue.status, class: 'status-pending' };
    const categoryAr = categoryMap[issue.category] || issue.category;

    const imageUrl = issue.photo ? issue.photo : 'https://via.placeholder.com/300x180?text=لا+توجد+صورة';

    const date = new Date(issue.created_at).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });

    card.innerHTML = `
        <img src="${imageUrl}" alt="صورة البلاغ" class="issue-image" onerror="this.src='https://via.placeholder.com/300x180?text=لا+توجد+صورة'">
        <div class="issue-content">
            <div class="issue-header">
                <span class="issue-id">#${issue.id}</span>
                <span class="status-badge ${statusInfo.class}">${statusInfo.text}</span>
            </div>
            <div class="issue-details">
                <p><i class="fas fa-tag"></i> ${categoryAr}</p>
                <p><i class="fas fa-map-marker-alt"></i> ${issue.city || 'غير محدد'}، ${issue.governorate || ''}</p>
                <p><i class="fas fa-clock"></i> ${date}</p>
            </div>
        </div>
    `;

    card.addEventListener('click', () => openIssueModal(issue, statusInfo, categoryAr, date, imageUrl));

    return card;
}

function openIssueModal(issue, statusInfo, categoryAr, date, imageUrl) {
    currentIssueId = issue.id;

    document.getElementById('modal-issue-id').textContent = `تفاصيل البلاغ #${issue.id}`;

    const statusBadge = document.getElementById('modal-issue-status');
    statusBadge.textContent = statusInfo.text;
    statusBadge.className = `status-badge ${statusInfo.class}`;

    document.getElementById('modal-issue-image').src = imageUrl;
    document.getElementById('modal-issue-location').textContent = `${issue.city || 'غير محدد'} - ${issue.governorate || ''}`;
    document.getElementById('modal-issue-category').textContent = categoryAr;
    document.getElementById('modal-issue-date').textContent = date;

    const reporterName = issue.reporter ? (issue.reporter.first_name + ' ' + issue.reporter.last_name).trim() : 'غير معروف';
    document.getElementById('modal-issue-reporter').textContent = reporterName || 'غير معروف';

    document.getElementById('modal-issue-desc').textContent = issue.description || 'لا يوجد وصف متاح لهذا البلاغ.';

    document.getElementById('issue-modal').style.display = 'flex';
}

async function updateIssueStatus(issueId, newStatus) {
    if (!issueId) return;

    try {
        const response = await fetch(`${API_BASE_URL}/issues/${issueId}/status/`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getCookie('token')}`
            },
            body: JSON.stringify({ status: newStatus })
        });

        if (response.ok) {
            showToast('تم تحديث حالة البلاغ بنجاح', 'success');
            document.getElementById('issue-modal').style.display = 'none';
            fetchGroupedIssues(); // Refresh data
        } else {
            const errData = await response.json();
            console.error('Update failed:', errData);
            showToast('فشل في تحديث الحالة', 'error');
        }
    } catch (error) {
        console.error('Error updating status:', error);
        showToast('خطأ في الاتصال بالخادم', 'error');
    }
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast show ${type}`;

    setTimeout(() => {
        toast.className = 'toast';
    }, 3000);
}
